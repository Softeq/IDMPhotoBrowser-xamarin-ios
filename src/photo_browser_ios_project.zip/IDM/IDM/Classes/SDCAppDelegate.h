//  Developed for Home by Softeq Development Corporation
//  http://www.softeq.com

#import <UIKit/UIKit.h>

@interface SDCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
