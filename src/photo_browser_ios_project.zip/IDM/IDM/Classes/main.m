//  Developed for Home by Softeq Development Corporation
//  http://www.softeq.com

#import <UIKit/UIKit.h>
#import "SDCAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SDCAppDelegate class]));
    }
}
