//  Developed for Home by Softeq Development Corporation
//  http://www.softeq.com

#import "SDCAppDelegate.h"

@implementation SDCAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
